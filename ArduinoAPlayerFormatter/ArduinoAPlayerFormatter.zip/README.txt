AduinoAPlayerFormatter:
put all your song in notConverted directory (note that all songs have to be named song1,2,3.wav)
and run ArduinoAPlayerFormatter.bat max song's it can convert is 255 but it can be increased if u 
open it in normal text editor and change 255 to your specific number

RemoveAllMP3:
when are you done with converting u can delete those mp3's
using this tool
same as ArduinoAPlayerFormatter max song's it can delete is 255 to increase it
step's are same as ArduinoAPlayerFormatter

